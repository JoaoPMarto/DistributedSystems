/* Grupo 05 
 * 
 * Nome: Sara Graça Nº 52804
 * Nome: João Marto Nº 52818
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "data.h"
#include "entry.h"
#include "tree.h"

/* Serializa uma estrutura data num buffer que será alocado
 * dentro da função. Além disso, retorna o tamanho do buffer
 * alocado ou -1 em caso de erro.
 */
int data_to_buffer(struct data_t *data, char **data_buf) {
    if (data_buf != NULL && data != NULL) {

        int size = sizeof(int) + data->datasize;
        char *ptr;
        *data_buf = malloc(size);
        ptr = *data_buf;
        memcpy(*data_buf, &(data->datasize), sizeof(int));
        *data_buf += sizeof(int);
        memcpy(*data_buf, data->data, data->datasize);

        *data_buf = ptr;

        return size;
    }
    return -1;
}

/* De-serializa a mensagem contida em data_buf, com tamanho
 * data_buf_size, colocando-a e retornando-a numa struct
 * data_t, cujo espaco em memoria deve ser reservado.
 * Devolve NULL em caso de erro.
 */
struct data_t *buffer_to_data(char *data_buf, int data_buf_size) {

    struct data_t *data;
    struct data_t *ptr;

    if (data_buf == NULL || data_buf_size < 0) {
        return NULL;
    }

    data = data_create(data_buf_size);

    ptr = data;
    memcpy(&(data->datasize), data_buf, sizeof(int));
    data_buf += sizeof(int);
    memcpy(data->data, data_buf, data->datasize);

    data = ptr;

    return data;
}

/* Serializa uma estrutura entry num buffer que será alocado
 * dentro da função. Além disso, retorna o tamanho deste
 * buffer ou -1 em caso de erro.
 */
int entry_to_buffer(struct entry_t *entry, char **entry_buf) {
    if (entry_buf != NULL && entry != NULL) {

        int size = sizeof(int) * 2 + strlen(entry->key) + entry->value->datasize + 1;
        char *ptr;

        *entry_buf = malloc(size);
        ptr = *entry_buf;

        int a = strlen(entry->key);

        memcpy(*entry_buf, &a, sizeof(int));
        *entry_buf += sizeof(int);
        memcpy(*entry_buf, entry->key, strlen(entry->key) + 1);
        *entry_buf += strlen(entry->key) + 1;
        memcpy(*entry_buf, &(entry->value->datasize), sizeof(int));
        *entry_buf += sizeof(int);
        memcpy(*entry_buf, entry->value->data, entry->value->datasize);

        *entry_buf = ptr;

        return size;
    }
    return -1;
}

/* De-serializa a mensagem contida em entry_buf, com tamanho
 * entry_buf_size, colocando-a e retornando-a numa struct
 * entry_t, cujo espaco em memoria deve ser reservado.
 * Devolve NULL em caso de erro.
 */
struct entry_t *buffer_to_entry(char *entry_buf, int entry_buf_size) {

    struct entry_t *entry;
    struct entry_t *ptr;
    struct data_t *data;
    int* aux;

    if (entry_buf == NULL || entry_buf_size < 0) {
        return NULL;
    }

    entry = malloc(sizeof(struct entry_t));
    entry->value = malloc(sizeof(struct data_t));
    entry->key = malloc (entry_buf_size - (sizeof(int) * 2) + 1);
    aux = malloc(sizeof(int) * 2);

    entry_initialize(entry);
    ptr = entry;

    memcpy(aux, entry_buf, sizeof(int));
    int n = *aux;
    aux += sizeof(int);
    entry_buf += sizeof(int);
    entry->key = malloc(n + 1);
    memcpy(entry->key, entry_buf, n + 1);
    entry_buf += n + 1;
    memcpy(aux, entry_buf, sizeof(int));
    n = *aux;
    entry_buf += sizeof(int);

    data = data_create2(n, strdup(entry_buf));
    memcpy(entry->value, data, data->datasize);

    entry = ptr;

    return entry;
}

/* Serializa uma estrutura tree num buffer que será alocado
 * dentro da função. Além disso, retorna o tamanho deste
 * buffer ou -1 em caso de erro.
 */
 int tree_to_buffer(struct tree_t *tree, char **tree_buf) {

    struct entry_t *entry;
    struct entry_t *entrada;

    if (tree_buf != NULL && tree != NULL) {
        char** chaves;
        char* ptr;
        char *chave;

        chaves = tree_get_keys(tree);

        chave = malloc(sizeof(char*));
        chave = *chaves;

        entry = getEntry(tree, chave);

        int sizeInitial = sizeof(int) * 4 + strlen(entry->key) + entry->value->datasize + 1;
        *tree_buf = malloc(sizeInitial);

        ptr = *tree_buf;

        int a = tree_size(tree);

        memcpy(*tree_buf, &a, sizeof(int));
        *tree_buf += sizeof(int);

        int sizeEntry = sizeof(int) * 2 + strlen(entry->key) + entry->value->datasize + 1;
        memcpy(*tree_buf, &sizeEntry, sizeof(int));
        *tree_buf += sizeof(int);

        int sizeOfFirstEntry = entry_to_buffer(entry, tree_buf);
        *tree_buf += sizeOfFirstEntry;

        int sizeAllEntrys = sizeInitial;
        free(chave);
        for (int i = 1; i < a; i++) {
            // Vai buscar a entry

            chave = malloc(sizeof(char*));
            chave = *chaves;

            entrada = getEntry(tree, chave);

            int sizeEntrada = sizeof(int) * 2 + strlen(entrada->key) + entrada->value->datasize + 1;
            sizeAllEntrys = sizeAllEntrys + (sizeof(int) + sizeEntrada);

            // Nao conseguimos meter o realloc a funcionar
            // Corretamente sem dar erro mas queriamos mudar o
            // Tamanho do tree_buf para ir metendo as entry(entradas)
            // *tree_buf = (char *)realloc(*tree_buf, sizeAllEntrys);

            memcpy(*tree_buf, &sizeEntrada, sizeof(int));
            *tree_buf += sizeof(int);

            entry_to_buffer(entrada, tree_buf);
            *tree_buf = *tree_buf + sizeEntrada;

            free(chave);
        }

        *tree_buf = ptr;

        return sizeAllEntrys;
    }
    return -1;
}

/* De-serializa a mensagem contida em tree_buf, com tamanho
 * tree_buf_size, colocando-a e retornando-a numa struct
 * tree_t, cujo espaco em memoria deve ser reservado.
 * Devolve NULL em caso de erro.
 */
struct tree_t *buffer_to_tree(char *tree_buf, int tree_buf_size) {

    struct tree_t *tree;
    struct tree_t *ptr;
    struct entry_t *entry;

    if (tree_buf == NULL || tree_buf_size < 0) {
        return NULL;
    }

    tree = tree_create();

    ptr = tree;

    int* n;
    n = malloc(sizeof(int));
    int treeSize;
    memcpy(n, tree_buf, sizeof(int));
    treeSize = *n;
    tree_buf += sizeof(int);

    int* j;
    int k;
    j = malloc(sizeof(int) * treeSize);

    for(int i = 0; i < treeSize; i++) {

        j = tree_buf;
        memcpy(j, tree_buf, sizeof(int));
        k = *j;
        tree_buf += sizeof(int);

        // Nao conseguimos meter a funcionar sem dar erro
        // Queriamos chamar o buffer_to_entry para retirar
        // Do tree_buf e ir criando a arvore dentro do for
        // entry = buffer_to_entry(tree_buf, k);
        // tree_buf += k;
        // tree_put(ptr, entry->key, entry->value);

    }

    tree = ptr;

    return tree;
}
