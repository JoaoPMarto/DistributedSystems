/* Grupo 05 
 * 
 * Nome: Sara Graça Nº 52804
 * Nome: João Marto Nº 52818
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "data.h"
#include "tree-private.h"

struct tree_t; /* A definir pelo grupo em tree-private.h */

/* Função para criar uma nova árvore tree vazia.
 * Em caso de erro retorna NULL.
 */
struct tree_t *tree_create() {

    struct tree_t* tree;
    tree = (struct tree_t*) malloc(sizeof(struct tree_t));

    if (tree == NULL) {
        return NULL;
    }

    tree->entry = (struct entry_t*) malloc(sizeof(struct entry_t));
    
    if(tree->entry == NULL) {
        free(tree);
        return NULL;
    }
    
    entry_initialize(tree->entry);
    tree->entry = NULL;
    tree->right = NULL;
    tree->left = NULL;

    return tree;
}

/* Função para libertar toda a memória ocupada por uma árvore.
 */
 
void tree_destroy(struct tree_t *tree) {
    if (tree == NULL) {
        return;
    } 

    entry_destroy(tree->entry);

    if (tree->right != NULL) {
        tree_destroy(tree->right);
    }
    if (tree->left != NULL) {
        tree_destroy(tree->left);
    }
}

/* Funcao auxiliar do tree_put
 */
struct tree_t *put (struct tree_t *tree, struct entry_t* entry) {
    if (tree->entry == NULL) {
        tree->entry = entry_dup(entry);
        return tree;
    }

    if (entry_compare(tree->entry, entry) == 0) {
        tree->entry = entry_dup(entry);
        return tree;
    } else if (entry_compare(tree->entry, entry) == 1) {
        if (tree->left == NULL) {
           tree->left = tree_create();
           tree->left->entry = entry_dup(entry);
           return tree; 
        }
        tree->left = put(tree->left, entry);
    } else {
        if (tree->right == NULL) {
           tree->right = tree_create();
           tree->right->entry = entry_dup(entry);
           return tree; 
        }    
        tree->right = put(tree->right, entry);
    }
    return tree;
}
/* Função para adicionar um par chave-valor à árvore.
 * Os dados de entrada desta função deverão ser copiados, ou seja, a
 * função vai *COPIAR* a key (string) e os dados para um novo espaço de
 * memória que tem de ser reservado. Se a key já existir na árvore,
 * a função tem de substituir a entrada existente pela nova, fazendo
 * a necessária gestão da memória para armazenar os novos dados.
 * Retorna 0 (ok) ou -1 em caso de erro.
 */
int tree_put(struct tree_t *tree, char *key, struct data_t *value) {

    struct entry_t *entry;
    struct tree_t *tree1;

    if (tree == NULL || key == NULL || value == NULL) {
        return -1;
    }
    
    entry = entry_create(key,value);
    tree1 = tree;
    
    if (put(tree, entry) != NULL) {
        tree = tree1;
        return 0;
    }
    
    entry_destroy(entry);

    return -1;  
}

/* Função para obter da árvore o valor associado à chave key.
 * A função deve devolver uma cópia dos dados que terão de ser
 * libertados no contexto da função que chamou tree_get, ou seja, a
 * função aloca memória para armazenar uma *CÓPIA* dos dados da árvore,
 * retorna o endereço desta memória com a cópia dos dados, assumindo-se
 * que esta memória será depois libertada pelo programa que chamou
 * a função.
 * Devolve NULL em caso de erro.
 */
struct data_t *tree_get(struct tree_t *tree, char *key) {
    if (tree == NULL || key == NULL) {
        return NULL;
    }
    if (tree->entry == NULL) {
        return NULL;
    }
    if (strcmp(tree->entry->key, key) == 0) {
        return data_dup(tree->entry->value);
    } else if (strcmp(tree->entry->key, key) > 0) {
        return tree_get(tree->left, key);
    } else {
        return tree_get(tree->right, key);
    }
    return NULL;
}

/* Função que devolve o minimo de uma arvore
 */
struct tree_t* min (struct tree_t *tree) {
    struct tree_t* t;
    t = tree;
    while (t && t->left != NULL) {
        t = t->left;
    }
    return t;
}
/* Função auxiliar do del
 */
struct tree_t* del(struct tree_t *tree, char *key) {
    
    if (tree == NULL) {
        return tree;
    }

    if (strcmp(tree->entry->key, key) == 0) {
        if (tree->left == NULL) {
            struct tree_t *temp = tree->right;
            free(tree);
            return temp;
        } else if (tree->right == NULL) {
            struct tree_t *temp = tree->left;
            free(tree);
            return temp;
        }

        struct tree_t *temp = min(tree->right);
        tree->entry->key = temp->entry->key;
        tree->right = del(tree->right, temp->entry->key);

    } else if (strcmp(tree->entry->key, key) > 0) {
        tree->left = del(tree->left, key);
    } else {
        tree->right = del(tree->right, key);
    }
    return tree;
}
/* Função para remover um elemento da árvore, indicado pela chave key,
 * libertando toda a memória alocada na respetiva operação tree_put.
 * Retorna 0 (ok) ou -1 (key not found).
 */
int tree_del(struct tree_t *tree, char *key) {
    struct tree_t *tree1;
    int n;
    if (tree == NULL || key == NULL) {
        return -1;
    }
    n = tree_size(tree);
    tree1 = tree;
    del(tree, key);

    if (n == tree_size(tree)) {
        tree = tree1;
        return -1;
    }
    tree = tree1;
    return 0;
}

/* Função que devolve o número de elementos contidos na árvore.
 */
int tree_size(struct tree_t *tree) {
    if (tree == NULL) {
        return 0;
    } 
    if (tree->entry == NULL) {
        return 0;
    }
    return tree_size(tree->left) + 1 + tree_size(tree->right);
}

/* Função que devolve a altura da árvore.
 */
int tree_height(struct tree_t *tree) {
    if (tree == NULL) {
        return 0;
    } else {
        int lHeight = tree_height(tree->left);
        int rHeight = tree_height(tree->right);

        if (lHeight >= rHeight) {
            return lHeight + 1;
        } else {
            return rHeight + 1;
        }
    }
}

/* Função auxiliar do tree_get_keys
 */
int get_keys(struct tree_t *tree, char **array, int i) {

    if (tree == NULL) {
        return i;
    }

    array[i] = tree->entry->key;
    i++;
    if (tree->left != NULL) {
        i = get_keys(tree->left, array, i);
    } 
    if (tree->right != NULL) {
        i = get_keys(tree->right, array, i);
    }
    return i;
}

/* Função que devolve um array de char* com a cópia de todas as keys da
 * árvore, colocando o último elemento do array com o valor NULL e
 * reservando toda a memória necessária.
 */
char **tree_get_keys(struct tree_t *tree) {
    char **array;

    if (tree == NULL) {
        return NULL;
    }
    
    array = malloc(tree_size(tree) * sizeof(char*));
    get_keys(tree, array, 0);
    return array;
}

/* Função que liberta toda a memória alocada por tree_get_keys().
 */
void tree_free_keys(char **keys) {
    if (keys != NULL) {
        int i = 0;
        while (i < sizeof(keys)/sizeof(keys[0])) {
            free(keys[i]);
            i++;
        }
        free(keys);
    }
}

/* Função que devolve uma entrada da tree correspondente a key dada 
 */
struct entry_t *getEntry(struct tree_t *tree,char *key) {
    struct entry_t *entry;
    struct data_t *data;
    data = tree_get(tree, key);
    entry = entry_create(key, data);
    
    return entry;
}

