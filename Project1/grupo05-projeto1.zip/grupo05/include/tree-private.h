/* Grupo 05 
 * 
 * Nome: Sara Graça Nº 52804
 * Nome: João Marto Nº 52818
 *
 */
#ifndef _TREE_PRIVATE_H
#define _TREE_PRIVATE_H

#include "tree.h"
#include "entry.h"

/* Estrutura que define as arvores
*/
struct tree_t {
	struct entry_t *entry; /* Entrada correspondente a arvore atual */
	struct tree_t *right; /* Arvore do lado direito  */
	struct tree_t *left; /* Arvore do lado esquerdo  */
};

/* Funcao que devolve o min de uma arvore
 */
struct tree_t* min (struct tree_t *tree);

/* Funcao que elimina uma entrada da arvore atraves da key dada
 */
struct tree_t* del(struct tree_t *tree, char *key);

/* Funcao que devolve um array de char* com a cópia de todas as keys da
 * árvore
 */
int get_keys(struct tree_t *tree, char **array, int i);

/* Função que devolve uma entrada da tree correspondente a key dada 
 */
struct entry_t *getEntry(struct tree_t *tree,char *key);

#endif
